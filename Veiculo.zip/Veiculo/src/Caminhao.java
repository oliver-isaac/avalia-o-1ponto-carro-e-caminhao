public class Caminhao extends Veiculo{
    public int eixos;

    public Caminhao(){}
    public Caminhao (String placa ,double tanque ,double consumo, int eixos){
        super (placa, tanque,consumo );
        this.eixos = eixos;
    }

    @Override
    public void verificarautonomia() {
        System.out.println("caminhao com "
                +eixos
                +" eixos"
        );
        super.verificarautonomia();
    }
}
