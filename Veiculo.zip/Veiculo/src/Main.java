//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;


public class Main {
    public static void main (String [] args){
        Scanner sc = new Scanner(System.in);

        Veiculo[] frota = new Veiculo[5];

        int i = 0;

        while (i < 5){
            System.out.println("\n veiculo "
                    +(i+1));

            System.out.println("placa: ");
            String placa = sc.next();

            System.out.println("tanque: ");
            double tanque = sc.nextDouble();

            System.out.print("Consumo: ");
            double consumo = sc.nextDouble();


            frota[i] = new Veiculo(placa, tanque, consumo);
            i++;

        }
        double soma = 0;


        for(int j = 0; j < 5; j++){

            System.out.println("\nPlaca: "+frota[j].getplaca());


            frota[j].verificarautonomia();

            soma += frota[j].getConsumomedio();


            if(frota[j].getConsumomedio() < 5){
                System.out.println("Revisão urgente!");
            }


            System.out.println("1-oleo 2-Pneu 3-Revisao");
            int opcao = sc.nextInt();

            switch(opcao){
                case 1:
                    System.out.println("Troca de oleo");
                    break;
                case 2:
                    System.out.println("Troca de pneus");
                    break;
                case 3:
                    System.out.println("Revisao geral");
                    break;
                default:
                    System.out.println("Opçao invalida");
            }
        }


        double media = soma / 5;

        System.out.println("\nMédia da frota: "+media);

        sc.close();
    }
}
