
    public class Veiculo {
        private String placa;
        private double tanquecapacidade;
        private double consumomedio;

        public Veiculo() {
        }

        public Veiculo(String placa, double tanquecapacidade, double consumomedio) {
            this.placa = placa;

            settanquecapacidade(tanquecapacidade);
            setconsumomedio(consumomedio);

        }

        public String getplaca() {
            return placa;
        }

        public double getTanquecapacidade() {
            return tanquecapacidade;
        }

        public double getConsumomedio() {
            return consumomedio;
        }

        public void settanquecapacidade(double tanquecapacidade) {
            if (tanquecapacidade > 0) {
                this.tanquecapacidade = tanquecapacidade;
            } else {
                System.out.println("tanque invalido");
            }
        }

        public void setconsumomedio(double consumomedio) {
            if (consumomedio > 0) {
                this.consumomedio = consumomedio;

            } else {
                System.out.println("consumo invalido");
            }
        }

        public void verificarautonomia() {
            double autonomia = tanquecapacidade * consumomedio;
            if (autonomia < 100) {
                System.out.println("aerta : abastecimento necesarrio");
            } else {
                System.out.println("autonomia : " + autonomia + " km");
            }
        }
    }
